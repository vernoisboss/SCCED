A Pen created at CodePen.io. You can find this one at https://codepen.io/joshhowenstine/pen/yLqgb.

 Based on code from pen from dmac37 http://codepen.io/dmac37/details/cfArp

Intended use to display recent posts thumbnails in a wordpress theme. 